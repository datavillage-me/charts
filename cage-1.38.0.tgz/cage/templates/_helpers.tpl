
{{- define "nodeSelectorTemplate" }}
nodeSelector:
  kubernetes.azure.com/security-type: "ConfidentialVM" #svd
  svd: "true"
  collaboration: "{{ .Release.Namespace | replace "app-" "" }}"
tolerations:
  - key: "svd"
    operator: "Exists"
    effect: "NoSchedule"
  - key: "collaboration"
    operator: "Equal"
    value: "{{ .Release.Namespace | replace "app-" ""  }}"
    effect: "NoSchedule"
{{- end }}
