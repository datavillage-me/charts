"""Add an HTTP header to each response."""
import logging
import ipaddress
import os
import json
from mitmproxy import http

class Sandboxing:
    def __init__(self):
        self.num = 0
        self.enabled = False

    def load(self, loader):
        self.enabled = os.environ.get("SANDBOX_ENABLED", "false").lower()!="false"
        white_list = os.environ.get("SANDBOX_WHITE_LIST", "[]")
        white_list = json.loads(white_list)
        self.white_list = [k for k in white_list]
        self.white_list += ["svc.cluster.local"]
        self.white_list += ["attest.azure.net"]
        self.namespace = os.environ.get("K8S_POD_NAMESPACE")
        if self.enabled:
           logging.warning(
             f"OPENING SANDBOXING FOR THE FOLLOWING DOMAINS"
           )
           for d in self.white_list:
              logging.warning(f"{d}")
        else:
           logging.warning(
             f"SANDBOXING IS DISABLED {os.environ.get('SANDBOX_ENABLED', 'false')}"
           )

    def sandboxing(self, flow):
       if(not self.enabled): 
           return

       host = flow.request.host
       try:
           address = ipaddress.ip_address(flow.request.host)

           if isinstance(address, ipaddress.IPv6Address):
              address = address.ipv4_mapped or address
          
       except:
           address = None

       
       is_private = address.is_private if address else False
       logging.info(
          f"CHECK SANDBOXING {host} {flow.request.pretty_host} {is_private}"
       )
       if(is_private):
           return


       #special case for loki
       #print("HOST=", host, self.namespace)
       if(host=="loki.datavillage.svc.cluster.local"):
           flow.request.headers['X-Scope-OrgID'] = self.namespace
           return
#curl -G -s  -H 'X-Scope-OrgID:app-cajhnkcp' "http://loki:3100/loki/api/v1/labels"


       for d in self.white_list:
           if host==d or host.endswith("."+d):
               return






       logging.error(f"Access to {host} is forbiden")
       flow.response = http.Response.make(
            503,  # (optional) status code
            f"Access to {host} is forbidden by datacage sandboxing rules\n",  # (optional) content
            {"Content-Type": "text/html"},  # (optional) headers
       )


    def requestheaders(self, flow):
            logging.info(
                f"request headers {flow.request}"
            )
            self.sandboxing(flow)


addons = [Sandboxing()]
